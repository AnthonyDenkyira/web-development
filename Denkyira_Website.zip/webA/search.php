<?php
// DB connection
$conn = new mysqli("localhost", "root", "usbw", "webA_test");
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Get search input safely
$search = isset($_GET['search']) ? $conn->real_escape_string($_GET['search']) : '';

if (!empty($search)) {
    // Search query (case-insensitive)
    $query = "SELECT * FROM product WHERE LOWER(name) LIKE LOWER('%$search%') LIMIT 10";
    $result = $conn->query($query);

    if ($result && $result->num_rows > 0) {
        // Send JSON response for AJAX
        $products = array();
        while ($row = $result->fetch_assoc()) {
            $products[] = $row;
        }
        header('Content-Type: application/json');
        echo json_encode($products);
    } else {
        echo json_encode([]);
    }
} else {
    echo json_encode([]);
}

$conn->close();
?>
