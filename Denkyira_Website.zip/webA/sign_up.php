<?php
// Do not output anything before this line
// Database connection
$host = 'localhost';
$user = 'root';
$password = 'usbw';
$dbname = 'webA_test';

$conn = new mysqli($host, $user, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Collect form data (POST)
$user_name = isset($_POST['user_name']) ? trim($_POST['user_name']) : '';
$email     = isset($_POST['email']) ? trim($_POST['email']) : '';
$password  = isset($_POST['password']) ? $_POST['password'] : '';
$c_password= isset($_POST['c_password']) ? $_POST['c_password'] : '';

// Validate input
if (empty($user_name) || empty($email) || empty($password) || empty($c_password)) {
    die("All fields are required.");
}

if (!filter_var($email, FILTER_VALIDATE_EMAIL)) {
    die("Invalid email format.");
}

if ($password !== $c_password) {
    die("Passwords do not match.");
}

// Check if email already exists
$stmt = $conn->prepare("SELECT id FROM users WHERE email = ?");
$stmt->bind_param("s", $email);
$stmt->execute();
$stmt->store_result();
if ($stmt->num_rows > 0) {
    die("Email is already registered.");
}
$stmt->close();

// Hash password
$hashed_password = md5($password); 

// Insert user
$stmt = $conn->prepare("INSERT INTO users (user_name, email, password_hash) VALUES (?, ?, ?)");
$stmt->bind_param("sss", $user_name, $email, $hashed_password);
if ($stmt->execute()) {
    // Redirect to login page after successful registration
    header("Location: login.html");
    exit();
} else {
    die("Registration failed. Try again.");
}

$stmt->close();
$conn->close();
?>
