const form = document.getElementById("form_id");

form.addEventListener("submit", function (e) {
  e.preventDefault();

  const formData = new FormData(form); // Use form, not `this` in arrow function

  fetch("sign_up.php", {
    method: "POST",
    body: formData,
  })
    .then((response) => response.text()) // or .json() depending on your PHP response
    .then((data) => {
      form.reset(); // Reset the form fields
      document.getElementById("response").innerHTML = data;
    })
    .catch((error) => {
      console.error("Error:", error);
    });
});
